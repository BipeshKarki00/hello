import 'package:sixam_mart/interfaces/repository_interface.dart';

abstract class AddressRepositoryInterface<AddressModel> implements RepositoryInterface<AddressModel> {

}