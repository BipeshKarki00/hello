# 6AM Mart

Welcome to 6AM Mart, your go-to destination for advanced e-commerce solutions tailored to meet all your needs. to enhance your business, don't worry i got you covered.

## Technologies Used

- Flutter & Flutterflow: 
- GetX as stateManagement 
- Laravel Backend for scalability purposes ...
- Firebase because there is no flutter project without it lol.
- Google APIs for maps (i used geolocator also).
- SharedPreferences as a light-weight local storage solution.
- Offline Shopping Support which makes the app more userfriendly.
- Multi-Language Support (localization).
- Meta APIs: for facebook login.
- Meta SEO
- Firebase Analytics to Gain valuable insights into user behaviors.
- Advanced Animations and Shimmers.

## Get Started
### it uses Flutter sdk: '>=3.2.0 <4.0.0'
``
flutter clean &&
flutter pub get &&
flutter run --release 
``

## For Questions :
hellalet.younes@gmail.com

thanku.

