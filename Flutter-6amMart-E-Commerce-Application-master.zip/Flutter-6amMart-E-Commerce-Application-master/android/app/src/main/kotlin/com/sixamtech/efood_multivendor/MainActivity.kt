package com.sixamtech.sixam_mart_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
