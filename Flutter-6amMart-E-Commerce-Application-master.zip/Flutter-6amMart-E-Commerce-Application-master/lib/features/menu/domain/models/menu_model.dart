
class MenuModel {
  String icon;
  String title;
  String route;

  MenuModel({required this.icon, required this.title, required this.route});
}